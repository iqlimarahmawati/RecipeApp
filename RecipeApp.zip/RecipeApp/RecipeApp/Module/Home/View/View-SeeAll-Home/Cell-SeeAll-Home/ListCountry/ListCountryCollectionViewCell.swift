//
//  ListCountryCollectionViewCell.swift
//  RecipeApp
//
//  Created by Iqlima Rahmawati on 13/04/23.
//

import UIKit

class ListCountryCollectionViewCell: UICollectionViewCell {
static let identifier = "ListCountryCollectionViewCell"
    
    @IBOutlet weak var countryImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()

    }

}
