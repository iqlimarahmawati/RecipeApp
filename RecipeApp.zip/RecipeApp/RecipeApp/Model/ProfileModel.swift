//
//  AccountModel.swift
//  RecipeApp
//
//  Created by Iqlima Rahmawati on 05/05/23.
//

import Foundation

struct ProfileModel {
    var imageProfile: String
    var nameProfile: String
    var emailProfile: String
    var passwordProfile: String
}
